## R assignment using R with SQL
#install.packages("RSQLite")
#install.packages("dbplyr")
#install.packages("rstudioapi")
#library(dbplyr)
#library(dplyr)
#library(rstudioapi)

library(RSQLite)
library(DBI)


# Create a connection to the database file
con <- dbConnect(RSQLite::SQLite(), "F:\\Jigsaw Academy\\Trainings\\SQL\\Final\\sample_db1.db")

# Any other database connection which has a server
#con=DBI::dbConnect(RPostgreSQL::PostgreSQL(),user='student',dbname='bulldozer',host="ec2-3-16-46-223.us-east-2.compute.amazonaws.com",password=rstudioapi::askForPassword('Password'))

# Create an ephemeral in-memory RSQLite database
#con <- dbConnect(RSQLite::SQLite(), ":memory:")

#List all tables in db
dbListTables(con)

# List field names of a table
dbListFields(con, 'tracks')

# Read media types field from DB
dbReadTable(con, 'media_types')

#SQL SELCT QUERIES
# Does not create data frame, still execute/ submits the query to DB
q2<- dbSendQuery(con,"SELECT * FROM tracks limit 10;")
class(q2)
dbFetch(q2)

?dbSendQuery

# Want to create a data frame use dbGetQuery
q1<- dbGetQuery(con,"SELECT * FROM tracks limit 10;")
class(q1)
dbFetch(q1)

?dbGetQuery
?dbFetch

# Create one more table in DB from R defalut data tables
dbWriteTable(con, "mtcars", mtcars)
dbListTables(con)

# Dropping table
dbGetQuery(con,"DROP TABLE mtcars;")
dbListTables(con)

# Disconnecting from the db
dbDisconnect(con)