create table customer_city
( cust_id INTEGER, city VARCHAR(40)
);
insert into customer_city
values
(1, 'Mumbai'),
(2, 'Mumbai'),
(3, 'Bangalore'),
(4, 'Mysore'),
(5, 'Hyderabad'),
(6, 'Pune');


create table customer_sales
( cust_id INTEGER, sales NUMERIC(10,2)
);
insert into customer_sales
values
(1, 100),
(2, 220.5),
(4, 50),
(5, 400),
(7, 30),
(8, 480.7);

-- LEFT JOIN
select a.cust_id as cust_a,b.cust_id as cust_b, city, sales
from customer_city as a
LEFT join 
customer_sales as b
on b.cust_id = a.cust_id;

-- inner JOIN
select a.cust_id as cust_a,b.cust_id as cust_b, city, sales
from customer_city as a
INNER join 
customer_sales as b
on b.cust_id = a.cust_id;

-- RIGHT JOIN
select a.cust_id as cust_a,b.cust_id as cust_b, city, sales
from customer_sales as a
LEFT join 
customer_city as b
on b.cust_id = a.cust_id;

-- FULL OUTER JOIN - see the issue..
select a.cust_id as cust_a,b.cust_id as cust_b, city, sales
from customer_city as a
FULL OUTER join 
customer_sales as b
on b.cust_id = a.cust_id;