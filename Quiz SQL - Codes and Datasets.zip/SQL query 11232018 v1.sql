 -- Comment one line at a time
 /* This is how you comment
 multiple lines at a time
 Got it!! */
 
 -- You can use the SELECT statement to perform a simple calculation as follows:
 
SELECT
 1 + 4;
 -- SOLVE - ? How do you give name to column here?
 
 
 
 
 -- You can use multiple expressions in the SELECT statement as follows:
 
 SELECT
 10 / 5 , 2 * 4 ;
 
 
 -- Select a few columns (trackid, name, composer and unitprice) from tracks table in DB
 
SELECT
 trackid,
 name,
 composer,
 unitprice
FROM
 tracks;
 
 /* SOLVE- ? How to select All the columns from tracks table? 
 - Way/s - Which one is easier and which is recommended? */
 
 
 
-- Get the cities from where customer belongs

SELECT
 city
FROM
 customers;
 -- SOLVE - ? What is the issue with above query?
 
 
 
 
 
 -- Use of DISTINCT
SELECT DISTINCT
 city
FROM
 customers;
 
 -- SOLVE - ? Get the companies of the customers
 
SELECT
 company
FROM
 customers;
  -- What do you observe in result set?
 
 
 
 
 -- Use DISTINCT
SELECT DISTINCT
 company
FROM
 customers;
 -- Again, what do you observe?
 
 
 
 -- USE OF ORDER BY
 -- Get name, milliseconds, and album id columns form tracks
 
SELECT
 name,
 milliseconds, 
        albumid
FROM
 tracks;
 
 
 -- Now get the same data sorted based on AlbumId column in ascending order
 
SELECT
 name,
 milliseconds, 
 albumid
FROM
 tracks
ORDER BY
 albumid ASC;

 
-- SOLVE:- Now sort the sorted result (by AlbumId) above...
-- by the Milliseconds column in descending order

SELECT
 name,
 milliseconds, 
 albumid
FROM
 tracks
ORDER BY
 albumid ASC,
        milliseconds DESC;
	
-- Using column positions in ORDER BY	
SELECT
 name,
 milliseconds, 
 albumid
FROM
 tracks
ORDER BY
 3,2;
 
-- Use of LIMIT clause
-- get the first 10 rows with track id and track name from the tracks table

SELECT
 trackId,
 name
FROM
 tracks
LIMIT 10;

-- get 10 rows starting from the 10th row in the tracks table

SELECT
 trackId,
 name
FROM
 tracks
LIMIT 10 OFFSET 10;



-- get the top 10 largest tracks in bytes
SELECT
 trackid,
 name,
 bytes
FROM
 tracks
ORDER BY
 bytes DESC
LIMIT 10;



-- USE of WHERE
-- SOLVE - ? Get all customers and their first name where company is missing

select customerid, firstname, company 
from customers
where company is NULL;

-- Get all tracks in the album id 1

SELECT
 name,
 milliseconds,
  bytes,
 albumid
FROM
 tracks
WHERE
 albumid = 1;



 
 -- Get tracks on the album 1 that have the length greater than 250,000 milliseconds
 
SELECT
 name,
 milliseconds,
 bytes,
 albumid
FROM
 tracks
WHERE
 albumid = 1
AND milliseconds > 250000;

-- Find which tracks are composed by all people with 'Smith' in thier names

SELECT
 name,
 albumid,
 composer
FROM
 tracks
WHERE
 composer LIKE '%Smith%'
ORDER BY
 albumid;



 
 -- Find tracks that have media type id 2 or 3 
 
 SELECT
 name,
 albumid,
 mediatypeid
FROM
 tracks
WHERE
 mediatypeid = 2 or mediatypeid = 3;
 
 
 
 -- You can achieve the same result using the IN operator
 
SELECT
 name, albumid, mediatypeid
FROM
 tracks
WHERE
 mediatypeid IN (2, 3);
 
	 
	 
	 
-- list of tracks whose genre id is not in a list of (1,2,3)

SELECT
 trackid,
 name,
 genreid
FROM
 tracks
WHERE
 genreid NOT IN (1,2,3);
 
 
 

 -- Use of BETWEEN operator
 -- finds invoices whose total is between 14.91 and 18.86:
 
SELECT
    InvoiceId,
    BillingAddress,
    Total
FROM
    invoices
WHERE
    Total BETWEEN 14.91 and 18.86    
ORDER BY
    Total; 

	
	
-- find the invoices whose total are not between 1 and 20
SELECT
    InvoiceId,
    BillingAddress,
    Total
FROM
    invoices
WHERE
    Total NOT BETWEEN 1 and 20
ORDER BY
    Total;    

	
	
-- finds invoices whose invoice dates are from January 1 2010 and January 31 2010:
SELECT
    InvoiceId,
    BillingAddress,
    InvoiceDate,
    Total
FROM
    invoices
WHERE
    InvoiceDate BETWEEN '2010-01-01' AND '2010-01-31'
ORDER BY
    InvoiceDate;
	
	
	
-- Use of wildcards % and _
-- ind the tracks with 'Wild' in their name
SELECT
 trackid,
 name 
FROM
 tracks
WHERE
 name LIKE 'Wild%';
 
 
 
SELECT
 trackid,
 name
FROM
 tracks
WHERE
 name LIKE '%Wild';
 

 
SELECT
 trackid,
 name 
FROM
 tracks
WHERE
 name LIKE '%Wild%';
 
 
 -- GROUP BY
 -- Find the number of tracks per album
 
SELECT
 albumid,
 COUNT(trackid) as track_count
FROM
 tracks
GROUP BY
 albumid;

 -- order above result by count of tracks
 
SELECT
 albumid,
 COUNT(trackid) as track_count
FROM
 tracks
GROUP BY
 albumid
ORDER BY 2 DESC;

 
-- Get total length and bytes for each album

SELECT
 albumid,
 sum(milliseconds) as length,
 sum(bytes) as size
FROM
 tracks
GROUP BY
 albumid;
 
  -- Get count of tracks by media type and genre
SELECT
 mediatypeid,
 genreid,
 count(trackid)
FROM
 tracks
GROUP BY
 mediatypeid,
 genreid;
 
 
 -- USE OF HAVING CLAUSE
 -- Get all albums and their total length and bytes with album length more than a minute

SELECT
 albumid,
 sum(milliseconds) as length,
 sum(bytes) as size
FROM
 tracks
GROUP BY
 albumid
HAVING sum(milliseconds) > 600000;
 
 -- SQL CASE when
 /* make a report of the customer groups with the logic that 
 if a customer locates in the USA, this customer belongs to the domestic group,
 otherwise the customer belongs to the foreign group.*/
 
 SELECT customerid,
       firstname,
       lastname,
	   country,
       CASE country 
           WHEN 'USA' 
               THEN 'Dosmetic' 
           ELSE 'Foreign' 
       END CustomerGroup
FROM 
    customers
ORDER BY 
    LastName,
    FirstName;
	
	
--Classify them based on eamil id

SELECT customerid,
       firstname,
       lastname,
       CASE  
           WHEN email like '%yahoo%' THEN 'YAHOO' 
           WHEN email like '%gmail%' THEN 'GMAIL' 
           ELSE 'Others' 
       END CustomerGroup
FROM 
    customers
ORDER BY 
    LastName,
    FirstName;

-- classify the tracks based on its length such as less a minute,
-- the track is short; between 1 and 5 minutes, the track is medium;
-- greater than 5 minutes, the track is long

SELECT
 trackid,
 name,
 CASE
 WHEN milliseconds < 60000 THEN
 'short'
 WHEN milliseconds > 6000 AND milliseconds < 300000 THEN 'medium'
 ELSE
 'long'
 END category
FROM
 tracks;
 
-- INSERT ROWS in TABLES

-- single row
INSERT INTO artists (name)
VALUES
 ('Bud Powell');
 
 -- multiple rows
 INSERT INTO artists (name)
VALUES
 ("Buddy Rich"),
 ("Candido"),
 ("Charlie Byrd");
 
 -- create backup of artists
 CREATE TABLE artists_backup(
 artistid INTEGER PRIMARY KEY AUTOINCREMENT,
 name NVARCHAR
);
INSERT INTO artists_backup SELECT
 artistid,
 name
FROM
 artists;
 
 -- SQL Update
 -- Update the last name of Jane (emp id = 3) as she got married to a Smith
UPDATE employees
SET lastname = 'Peacock'
WHERE
 employeeid = 3;
 
 /* Suppose Park Margaret locates in Toronto and you want to change his address, 
 city, and state information.*/
 
 UPDATE employees
SET city = 'Toronto',
    state = 'ON',
    postalcode = 'M5P 2N7'
WHERE
    employeeid = 4;

-- Deleting rows from table
DELETE
FROM
 artists_backup
WHERE
 artistid = 1;
 -- Delete based on condition
DELETE
FROM
 artists_backup
WHERE
 name LIKE '%Santana%';
 
 -- Removing all rows of database
 DELETE
FROM
 artists_backup;
 
-- Dropping a table
drop table artists_backup;


-- JOINS
-- Inner join

-- get the album titles for all tracks

SELECT
 trackid,
 name,
 title
FROM
 tracks
INNER JOIN albums ON albums.albumid = tracks.albumid;

-- How do you validate join is correct?
SELECT
    trackid,
    name,
    tracks.albumid AS album_id_tracks,
    albums.albumid AS album_id_albums,
    title
FROM
    tracks
    INNER JOIN albums ON albums.albumid = tracks.albumid;

-- inner join – 3 tables example
-- albums have multiple tracks and artists have multiple albums
SELECT
    trackid,
    tracks.name AS track,
    albums.title AS album,
    artists.name AS artist
FROM
    tracks
    INNER JOIN albums ON albums.albumid = tracks.albumid
    INNER JOIN artists ON artists.artistid = albums.artistid;

-- SOLVE - ? How to get tracks and albums of artist with ID = 10
SELECT
 trackid,
 tracks.name AS Track,
 albums.title AS Album,
 artists.name AS Artist
FROM
 tracks
INNER JOIN albums ON albums.albumid = tracks.albumid
INNER JOIN artists ON artists.artistid = albums.artistid
WHERE
 artists.artistid = 10;
 
 -- Find the artists who do not have any albums
SELECT
 artists.ArtistId,
 albumId
FROM
 artists
LEFT JOIN albums ON albums.artistid = artists.artistid
ORDER BY
 albumid;
 
--OR
 SELECT
 artists.ArtistId,
 albumId
FROM
 artists
LEFT JOIN albums ON albums.artistid = artists.artistid
WHERE
 albumid IS NULL;
 
 -- CROSS JOIN - creates cartesian product of n*m rows
 -- Eg. Get a pack of card data
 CREATE TABLE ranks (
    rank TEXT NOT NULL
);
 
CREATE TABLE suits (
    suit TEXT NOT NULL
);
 
INSERT INTO ranks(rank) 
VALUES('2'),('3'),('4'),('5'),('6'),('7'),('8'),('9'),('10'),('J'),('Q'),('K'),('A');
 
INSERT INTO suits(suit) 
VALUES('Clubs'),('Diamonds'),('Hearts'),('Spades');

SELECT rank,
       suit
  FROM ranks
       CROSS JOIN
       suits
ORDER BY suit;


-- Drop tables created
drop table ranks;
drop table suits;

-- Note - SQLite does not support RIGHT JOIN and FULL OUTER join


--------------------------------------------------------------------
-- SELF join - classic example
SELECT m.firstname || ' ' || m.lastname AS 'Manager',
       e.firstname || ' ' || e.lastname AS 'Direct report' 
FROM employees e
INNER JOIN employees m ON m.employeeid = e.reportsto
ORDER BY manager;

-- use the self-join technique to find the employees located in the same city as the following query
SELECT DISTINCT
 e1.city,
 e1.firstName || ' ' || e1.lastname AS fullname
FROM
 employees e1
INNER JOIN employees e2 ON e2.city = e1.city 
   AND (e1.firstname <> e2.firstname AND e1.lastname <> e2.lastname)
ORDER BY
 e1.city;
 
-- Get the number of tracks per album along with album title
select a.albumID , b.title, count (trackid) as track_count
from 
tracks  as a
left join
albums as b on a.albumid = b.albumid
group by 1,2;

-- GROUP BY with HAVING clause - to filter by aggregate value in group by
-- get the albums that have more than 15 tracks

SELECT
 tracks.albumid,
 title,
 COUNT(trackid)
FROM
 tracks
INNER JOIN albums ON albums.albumid = tracks.albumid
GROUP BY
 tracks.albumid
HAVING COUNT(trackid) > 15;

 
 -- Get the album id, album title, maximum, minimum and the average length of tracks
 SELECT
 tracks.albumid,
 title,
 min(milliseconds),
 max(milliseconds),
 round(avg(milliseconds),2)
FROM
 tracks
INNER JOIN albums ON albums.albumid = tracks.albumid
GROUP BY
 tracks.albumid;
 
-- find albums that have the total length greater than 60,000,000 milliseconds
SELECT
 tracks.albumid,
 title,
 sum(Milliseconds) AS length
FROM
 tracks
INNER JOIN albums ON albums.AlbumId = tracks.AlbumId
GROUP BY
 tracks.albumid
HAVING
 length > 60000000;
 
 -- union AND UNION all
 SELECT
 firstname,
 lastname
FROM
 employees
UNION  ALL
SELECT
 firstname,
 lastname
FROM
 employees;
 
 -- Appending customer and employees names
 
 SELECT
 firstname,
 lastname
FROM
 employees
UNION
SELECT
 firstname,
 lastname
FROM
 customers
 
ORDER BY
 firstname,
 lastname;
 
 -- USE Of EXCEPT operator
 -- finds artist ids of artists who do not have any album in the albums table
SELECT ArtistId
FROM artists
EXCEPT
SELECT ArtistId
FROM albums;

-- 	intersect operator
-- find customers who have invoices
SELECT CustomerId
FROM customers
INTERSECT
SELECT CustomerId
FROM invoices
ORDER BY CustomerId;

-- SQL Subquery

-- Find all the tracks in the album with the title Let There Be Rock

SELECT trackid,
       name,
       tracks.albumid
  FROM tracks left join albums
  on tracks.albumid = albums.albumid
 where albums.Title = 'Let There Be Rock';
 
 --OR
 SELECT trackid,
       name,
       albumid
  FROM tracks
 WHERE albumid = (
                     SELECT albumid
                       FROM albums
                      WHERE title = 'Let There Be Rock'
                 );

				 
-- Get the tracks that belong to the artist id 12 (use of subquery within In)
 SELECT
 trackid,
 name,
 albumid
FROM
 tracks
WHERE
	 albumid IN (
		 SELECT
		 albumid
		 FROM
		 albums
		 WHERE
		 artistid = 12
	 );

	 
	 
--  Find the customers whose sales representatives are in Canada

SELECT customerid,
       firstname,
       lastname
  FROM customers
 WHERE supportrepid IN (
           SELECT employeeid
             FROM employees
            WHERE country = 'Canada'
       );
	   
--OR
SELECT a.customerid,
       a.firstname,
       a.lastname
  FROM customers as a LEFT join employees as b
  on a.SupportRepId = b.EmployeeID
  where b.country = 'Canada';

-- Get average album size in bytes

SELECT avg(album.size) 
  FROM (
           SELECT sum(bytes) as size
             FROM tracks
            GROUP BY albumid
       )
       AS album;
