

This assignment deals with the Indian Premier League dataset. It contains information about 568 cricket matches played in the duration from 2008-2016. The datasets are available in the 'data_files' directory.

#### Files:
1) schemas.sql:
	Defines and creates Schemas of the tables in the database
2) load_data.sql:
	Loads the data into the schemas created by schemas.sql
3) queries.sql:
	SQL queries corresponding to the Queries in QuestionsIPL.txt

